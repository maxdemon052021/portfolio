$(document).ready(function() {

    window.sr = ScrollReveal({
        duration: 2000,
        distance: '-50px',
        reset: true
    });

    sr.reveal('.sr');

});