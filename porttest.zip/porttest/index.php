<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= $data['title']; ?></title>
    <link rel="stylesheet" href="/porttest/css/all.min.css">
    <link rel="stylesheet" href="/porttest/css/bootstrap.min.css">
    <link rel="stylesheet" href="/porttest/css/my-style.css">
</head>
<body data-spy="scroll" data-target="#main-nav" data-offset="50">

    <div class="container-fluid">

        <nav id="main-nav" class="navbar navbar-expand-lg navbar-light bg-light shadow sticky-top">
            <a class="navbar-brand" href="/porttest">-=D'Max'05=-</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse text-center" id="navbarNavAltMarkup">
                <div class="dropdown-divider"></div>
                <div class="navbar-nav ml-auto">
                    <a href="#welcome" class="nav-item nav-link mx-lg-2 active">Home</a>
                    <a href="#about" class="nav-item nav-link mx-lg-2">About</a>
                    <a href="#service" class="nav-item nav-link mx-lg-2">Service</a>
                    <a href="#project" class="nav-item nav-link mx-lg-2">Project</a>
                    <a href="#contact" class="nav-item nav-link mx-lg-2">Contact</a>
                </div>
            </div>
        </nav>

        <section id="welcome" class="mt-2 shadow sr">
            <div class="background"></div>
            <div class="overlay"></div>
            <div class="content d-flex justify-content-center align-items-center text-center">
                <div class="items text-light">
                    <h4 class="sr">Hi, Welcome to my Portfolio.</h4>
                    <h1 class="mt-5 sr">I am</h1>
                    <h1 class="font-weight-bold sr">Jonard Solayao</h1>
                    <h5 class="text-uppercase font-weight-bold my-5 border-bottom border-light sr d-inline-block">Self Taught Developer</h5>
                    <div class="btn-area sr">
                        <button class="btn btn-outline-light btn-lg text-uppercase font-weight-bold" value="get-cv">Get my CV</button>
                        <button class="btn btn-outline-light btn-lg text-uppercase font-weight-bold" value="hire-me">Hire Me</button>
                    </div>
                </div>
            </div>
        </section>

        <section id="about" class="pt-5 pb-3 sr">
            <div class="row align-items-center justify-content-center">
                <div class="col-12 col-md-10 col-lg-9">
                    <div class="jumbotron bg-transparent shadow text-center mb-0">
                        <div class="items">
                            <h3 class="font-weight-bold mb-3 sr">Let me Introduce Myself</h3>
                            <p class="lead sr">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem temporibus explicabo, neque, molestias assumenda reprehenderit omnis suscipit libero hic nesciunt.
                            </p>
                            <p class="lead sr">
                                Cupiditate repudiandae, consectetur deleniti possimus ipsam! Accusantium eveniet saepe similique. Dicta, natus. Excepturi vel dolores nemo dolor quaerat unde non, deleniti aut ipsam nam nulla pariatur veniam!
                            </p>
                            <button class="btn btn-outline-dark btn-lg text-uppercase font-weight-bold mt-4 sr">Download CV</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <section id="service" class="pt-5 text-center sr">
            <h3 class="font-weight-bold mb-5 mt-3 sr">Programming Language & Tools</h3>
            <div class="row justify-content-center">
                <div class="col-12 col-md-10 col-lg-9">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-6 col-md-4 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fab fa-html5 text-danger" style="font-size: 4rem;"></i>
                                <h4 class="font-weight-bold text-uppercase">HTML</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fab fa-css3-alt text-primary" style="font-size: 4rem;"></i>
                                <h4 class="font-weight-bold text-uppercase">CSS</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fab fa-js-square text-warning" style="font-size: 4rem;"></i>
                                <h4 class="font-weight-bold text-uppercase">Javascript</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fab fa-php text-info" style="font-size: 4rem;"></i>
                                <h4 class="font-weight-bold text-uppercase">PHP</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fab fa-bootstrap" style="font-size: 4rem; color: #301c82;"></i>
                                <h4 class="font-weight-bold text-uppercase">Bootstrap</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <img src="/porttest/img/jquery.png" style="width: 4rem; height: 4rem; background-color: #390ce4;" class="rounded">
                                <h4 class="font-weight-bold text-uppercase">JQuery</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fab fa-font-awesome text-primary" style="font-size: 4rem;"></i>
                                <h4 class="font-weight-bold text-uppercase">Font Awesome</h4>
                            </div>
                        </div>
                        <div class="col-6 col-md-4 mb-4">
                            <div class="items sr">
                                <i class="fas fa-database text-primary" style="font-size: 4rem;"></i>
                                <h4 class="font-weight-bold text-uppercase">MySql</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <section id="project" class="py-4 text-center sr">
            <h3 class="font-weight-bold text-uppercase my-5 text-center sr">All Project Here</h3>
            <div class="row align-items-center justify-content-center">
                <div class="col-12 col-md-6 col-lg-4 mb-4 sr">
                    <div class="card text-center bg-dark text-light">
                        <img src="/porttest/img/banner.jpg" class="card-img-top">
                        <div class="card-body sr">
                            <div class="card-title">
                                <h3 class="font-weight-bold sr">Projects 01</h3>
                            </div>
                            <p class="lead sr">
                                Programming language & tools i use.
                            </p>
                        </div>
                        <div class="card-footer py-3">
                            <button class="btn btn-outline-light font-weight-bold text-uppercase sr">View Project</button>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4 sr">
                    <div class="card text-center bg-dark text-light">
                        <img src="/porttest/img/banner.jpg" class="card-img-top">
                        <div class="card-body sr">
                            <div class="card-title">
                                <h3 class="font-weight-bold sr">Projects 01</h3>
                            </div>
                            <p class="lead sr">
                                Programming language & tools i use.
                            </p>
                        </div>
                        <div class="card-footer py-3">
                            <button class="btn btn-outline-light font-weight-bold text-uppercase sr">View Project</button>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4 sr">
                    <div class="card text-center bg-dark text-light">
                        <img src="/porttest/img/banner.jpg" class="card-img-top">
                        <div class="card-body sr">
                            <div class="card-title">
                                <h3 class="font-weight-bold sr">Projects 01</h3>
                            </div>
                            <p class="lead sr">
                                Programming language & tools i use.
                            </p>
                        </div>
                        <div class="card-footer py-3">
                            <button class="btn btn-outline-light font-weight-bold text-uppercase sr">View Project</button>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4 sr">
                    <div class="card text-center bg-dark text-light">
                        <img src="/porttest/img/banner.jpg" class="card-img-top">
                        <div class="card-body sr">
                            <div class="card-title">
                                <h3 class="font-weight-bold sr">Projects 01</h3>
                            </div>
                            <p class="lead sr">
                                Programming language & tools i use.
                            </p>
                        </div>
                        <div class="card-footer py-3">
                            <button class="btn btn-outline-light font-weight-bold text-uppercase sr">View Project</button>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4 sr">
                    <div class="card text-center bg-dark text-light">
                        <img src="/porttest/img/banner.jpg" class="card-img-top">
                        <div class="card-body sr">
                            <div class="card-title">
                                <h3 class="font-weight-bold sr">Projects 01</h3>
                            </div>
                            <p class="lead sr">
                                Programming language & tools i use.
                            </p>
                        </div>
                        <div class="card-footer py-3">
                            <button class="btn btn-outline-light font-weight-bold text-uppercase sr">View Project</button>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-6 col-lg-4 mb-4 sr">
                    <div class="card text-center bg-dark text-light">
                        <img src="/porttest/img/banner.jpg" class="card-img-top">
                        <div class="card-body sr">
                            <div class="card-title">
                                <h3 class="font-weight-bold sr">Projects 01</h3>
                            </div>
                            <p class="lead sr">
                                Programming language & tools i use.
                            </p>
                        </div>
                        <div class="card-footer py-3">
                            <button class="btn btn-outline-light font-weight-bold text-uppercase sr">View Project</button>
                        </div>
                    </div>
                </div>
            </div>
            <button class="btn btn-dark btn-lg font-weight-bold text-uppercase sr">See More Project</button>
        </section>
        <hr>
        <section id="contact" class="pt-5 sr">
            <div class="row justify-content-center">
                <div class="col-12 col-md-10 col-lg-9">
                    <div class="card bg-dark text-light text-center">
                        <div class="card-header">
                            <h3 class="card-title font-weight-bold text-uppercase my-4 sr">Contact Form</h3>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="form-group row sr">
                                    <label class="col-sm-2 col-form-label font-weight-bold">Name:</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" placeholder="Your Name...">
                                    </div>
                                </div>
                                <div class="form-group row sr">
                                    <label class="col-sm-2 col-form-label font-weight-bold">E-Mail:</label>
                                    <div class="col-sm-10">
                                        <input type="email" class="form-control" placeholder="Your E-Mail...">
                                    </div>
                                </div>
                                <div class="form-group row sr">
                                    <label class="col-sm-2 col-form-label font-weight-bold">Message:</label>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" placeholder="Your Message..." rows="3"></textarea>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-footer">
                            <button class="btn btn-outline-light btn-lg font-weight-bold text-uppercase form-control sr">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <footer class="pt-5">
            <div class="jumbotron bg-dark text-light text-center mb-0 sr">
                <h3 class="brand font-weight-bold mb-4 sr">-=D'Max'05=-</h3>
                <p class="lead sr">
                    <span class="font-weight-bold">Jonard Solayao</span> | All Copy Rights Reserved &copy; 2021
                </p>
            </div>
        </footer>

    </div>


    <script src="/porttest/js/all.min.js"></script>
    <script src="/porttest/js/jquery.min.js"></script>
    <script src="/porttest/js/bootstrap.min.js"></script>
    <script src="/porttest/js/scrollreveal.min.js"></script>
    <script src="/porttest/js/my-script.js"></script>

</body>
</html>