<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= $data['title']; ?></title>
    <link rel="stylesheet" href="/mdbootstrap/css/all.min.css">
    <link rel="stylesheet" href="/mdbootstrap/css/mdb.min.css">
    <link rel="stylesheet" href="/mdbootstrap/css/my-style.css">
</head>
<body data-mdb-spy="scroll" data-mdb-target="#main-nav" data-mdb-offset="0">

    <div id="loading-screen">
        <div class="spinner-border text-light" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>


    <nav id="main-nav" class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
        <!-- Container Wrapper -->
        <div class="container-fluid">
            <!-- Navbar Brand -->
            <a class="navbar-brand fs-6 mx-2" href="/mdbootstrap">-=D'Max'05=-</a>
            <!-- Navbar Menu Button -->
            <button class="navbar-toggler" type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <!-- Navbar Brand Links -->
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="dropdown-divider"></div>
                <div class="navbar-nav ms-auto">
                    <a class="nav-link mx-2 active" aria-current="page" href="#welcome">Home</a>
                    <a class="nav-link mx-2" href="#about">About</a>
                    <a class="nav-link mx-2" href="#service">Service</a>
                    <a class="nav-link mx-2" href="#project">Project</a>
                    <a class="nav-link mx-2" href="#contact">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container-fluid">

        <div id="welcome" class="reveal rounded shadow-1-strong mt-3">
            <div class="bg-image" style="background-image: url(/mdbootstrap/img/showcase.jpg); width: 100%; height: 100%; z-index: 1;"></div>
            <div class="overlay"></div>
            <div class="content-wrapper d-flex justify-content-center align-items-center">
                <div class="content text-center text-light reveal">
                    <h1 class="fs-5 fs-md-4 fs-lg-3 mb-5 mt-0">Hi, Welcome to my Portfolio</h1>
                    <h1 class="fs-2 fs-md-1">I am</h1>
                    <h1 class="fs-2 fs-md-1 fw-bold">Jonard Solayao</h1>
                    <h1 class="fs-6 fs-md-5 fs-lg-4 fw-bold text-uppercase text-monospace my-5">Self Taught Developer</h1>
                    <button class="btn btn-outline-light btn-lg fw-bold text-uppercase reveal">Get my CV</button>
                    <button class="btn btn-outline-light btn-lg fw-bold text-uppercase reveal">Hire Me</button>
                </div>
            </div>
        </div>

        <div id="about" class="reveal pt-4">
            <div class="content-wrapper rounded shadow-1-strong px-3 pb-3 px-md-5 pb-md-3">
                <div class="content text-center">
                    <h1 class="fs-3 fs-md-2 fs-lg-1 fw-bold text-capitalize py-5 reveal">Let me introduce myself</h1>
                    <p class="fs-6 fs-md-4 fs-lg-3 reveal">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati inventore, officiis pariatur, perferendis explicabo fugit nobis saepe maxime similique dolorem tempore temporibus dolores at iure, excepturi laudantium officia aperiam aspernatur.
                    </p>
                    <p class="fs-6 fs-md-4 fs-lg-3 reveal">
                        Minus nostrum accusantium vero eos, sit magni at quod minima totam? Atque, similique, magnam. Consequuntur corporis ab inventore veniam, nostrum minus quia expedita mollitia aque ducimus odio maiores quos soluta rem iste cupiditate vero in! Temporibus, voluptates at esse veniam ullam accusantium.
                    </p>
                </div>

                <div class="row justify-content-center">
                    <div class="col-12 col-md-10 col-lg-9 mt-3">
                        <!-- Carousel wrapper -->
                        <div
                            id="carouselBasicExample"
                            class="carousel slide carousel-fade carousel-dark rounded shadow overflow-hidden reveal"
                            data-mdb-ride="carousel"
                            >
                            <!-- Indicators -->
                            <div class="carousel-indicators">
                                <button
                                    type="button"
                                    data-mdb-target="#carouselBasicExample"
                                    data-mdb-slide-to="0"
                                    class="active"
                                    aria-current="true"
                                    aria-label="Slide 1"
                                    ></button>
                                <button
                                    type="button"
                                    data-mdb-target="#carouselBasicExample"
                                    data-mdb-slide-to="1"
                                    aria-label="Slide 2"
                                    ></button>
                                <button
                                    type="button"
                                    data-mdb-target="#carouselBasicExample"
                                    data-mdb-slide-to="2"
                                    aria-label="Slide 3"
                                    ></button>
                            </div>

                            <!-- Inner -->
                            <div class="carousel-inner">
                                <!-- Single item -->
                                <div class="carousel-item" data-mdb-interval="6000">
                                    <img
                                    src="/mdbootstrap/img/showcase.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                    />
                                    <div class="carousel-caption d-none d-md-block">
                                        <h5>First slide label</h5>
                                        <p>
                                            Nulla vitae elit libero, a pharetra augue mollis interdum.
                                        </p>
                                    </div>
                                </div>

                                <!-- Single item -->
                                <div class="carousel-item active" data-mdb-interval="6000">
                                    <img
                                    src="/mdbootstrap/img/banner.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                    />
                                    <div class="carousel-caption d-none d-md-block text-light">
                                        <h5>Second slide label</h5>
                                        <p>
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                                        </p>
                                    </div>
                                </div>

                                <!-- Single item -->
                                <div class="carousel-item" data-mdb-interval="6000">
                                    <img
                                    src="/mdbootstrap/img/showcase2.jpg"
                                    class="d-block w-100"
                                    alt="..."
                                    />
                                    <div class="carousel-caption d-none d-md-block text-dark">
                                        <h5>Third slide label</h5>
                                        <p>
                                            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Inner -->

                            <!-- Controls -->
                            <button
                                class="carousel-control-prev"
                                type="button"
                                data-mdb-target="#carouselBasicExample"
                                data-mdb-slide="prev"
                                >
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button
                                class="carousel-control-next"
                                type="button"
                                data-mdb-target="#carouselBasicExample"
                                data-mdb-slide="next"
                                >
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                        <!-- Carousel wrapper -->
                    </div>
                </div>
            </div>
        </div>

        <div id="service" class="reveal pt-4">
            <div class="content-wrapper rounded shadow-1-strong p-3 px-md-5 py-md-4">
                <div class="content text-center">
                    <h1 class="fs-3 fs-md-2 fs-lg-1 fw-bold text-capitalize py-5 reveal">Programming Language & Tools</h1>
                    <p class="fs-6 fs-md-4 fs-lg-3 reveal">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati inventore, officiis pariatur, perferendis explicabo fugit nobis saepe maxime similique dolorem tempore temporibus dolores at iure, excepturi laudantium officia aperiam aspernatur.
                    </p>
                </div>
                <div class="row justify-content-center text-center">
                    <div class="col-12 col-md-10 col-lg-8 mt-4">
                        <div class="row justify-content-center align-items-center g-3">
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fab fa-html5 text-danger" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">HTML</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fab fa-css3-alt text-primary" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">CSS</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fab fa-js-square text-warning" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">Javascript</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fab fa-php text-info" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">PHP</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fab fa-bootstrap text-secondary" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">Bootstrap</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <img src="/mdbootstrap/img/jquery.png" style="width: 5rem; height: 5rem;" class="rounded bg-primary">
                                    <h5 class="fw-bold fs-6">JQuery</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fa fa-database text-primary" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">MySQL</h5>
                                </div>
                            </div>
                            <div class="col-6 col-md-4">
                                <div class="items shadow rounded p-4 reveal">
                                    <i class="fab fa-font-awesome text-primary" style="font-size: 5rem;"></i>
                                    <h5 class="fw-bold fs-6">Font Awesome</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="project" class="reveal pt-4">
            <div class="content-wrapper rounded shadow-1-strong px-3 pb-3 px-md-5 pb-md-3 text-center reveal">
                <div class="content">
                    <h1 class="fs-3 fs-md-2 fs-lg-1 fw-bold text-capitalize py-5 reveal">My Projects</h1>
                    <p class="fs-6 fs-md-4 fs-lg-3 reveal mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium asperiores doloribus ducimus harum porro possimus dignissimos maiores totam ea eveniet!
                    </p>
                </div>
                <div class="row justify-content-center align-items-center g-4">
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card bg-dark text-light reveal">
                            <img
                            src="/mdbootstrap/img/banner.jpg"
                            class="card-img-top"
                            alt="..."
                            />
                            <div class="card-body">
                                <h5 class="card-title fw-bold reveal">Project Title</h5>
                                <p class="card-text mt-4 reveal">
                                    Some quick example text to build on the card title and make up the bulk of the
                                    card's content.
                                </p>
                                <a href="#!" class="btn btn-outline-light fw-bold my-4 reveal">View Project</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card bg-dark text-light reveal">
                            <img
                            src="/mdbootstrap/img/banner.jpg"
                            class="card-img-top"
                            alt="..."
                            />
                            <div class="card-body">
                                <h5 class="card-title fw-bold reveal">Project Title</h5>
                                <p class="card-text mt-4 reveal">
                                    Some quick example text to build on the card title and make up the bulk of the
                                    card's content.
                                </p>
                                <a href="#!" class="btn btn-outline-light fw-bold my-4 reveal">View Project</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card bg-dark text-light reveal">
                            <img
                            src="/mdbootstrap/img/banner.jpg"
                            class="card-img-top"
                            alt="..."
                            />
                            <div class="card-body">
                                <h5 class="card-title fw-bold reveal">Project Title</h5>
                                <p class="card-text mt-4 reveal">
                                    Some quick example text to build on the card title and make up the bulk of the
                                    card's content.
                                </p>
                                <a href="#!" class="btn btn-outline-light fw-bold my-4 reveal">View Project</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card bg-dark text-light reveal">
                            <img
                            src="/mdbootstrap/img/banner.jpg"
                            class="card-img-top"
                            alt="..."
                            />
                            <div class="card-body">
                                <h5 class="card-title fw-bold reveal">Project Title</h5>
                                <p class="card-text mt-4 reveal">
                                    Some quick example text to build on the card title and make up the bulk of the
                                    card's content.
                                </p>
                                <a href="#!" class="btn btn-outline-light fw-bold my-4 reveal">View Project</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card bg-dark text-light reveal">
                            <img
                            src="/mdbootstrap/img/banner.jpg"
                            class="card-img-top"
                            alt="..."
                            />
                            <div class="card-body">
                                <h5 class="card-title fw-bold reveal">Project Title</h5>
                                <p class="card-text mt-4 reveal">
                                    Some quick example text to build on the card title and make up the bulk of the
                                    card's content.
                                </p>
                                <a href="#!" class="btn btn-outline-light fw-bold my-4 reveal">View Project</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-4">
                        <div class="card bg-dark text-light reveal">
                            <img
                            src="/mdbootstrap/img/banner.jpg"
                            class="card-img-top"
                            alt="..."
                            />
                            <div class="card-body">
                                <h5 class="card-title fw-bold reveal">Project Title</h5>
                                <p class="card-text mt-4 reveal">
                                    Some quick example text to build on the card title and make up the bulk of the
                                    card's content.
                                </p>
                                <a href="#!" class="btn btn-outline-light fw-bold my-4 reveal">View Project</a>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="btn btn-outline-dark btn-lg fw-bold mt-4 reveal">See More</button>
            </div>
        </div>

        <div id="contact" class="reveal pt-4">
            <div class="content-wrapper rounded shadow-1-strong px-3 pb-3 px-md-5 pb-md-3 text-center reveal">
                <div class="content">
                    <h1 class="fs-3 fs-md-2 fs-lg-1 fw-bold text-capitalize py-5 reveal">Contact Us</h1>
                    <p class="fs-6 fs-md-4 fs-lg-3 reveal mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Praesentium asperiores doloribus ducimus harum porro possimus dignissimos maiores totam ea eveniet!
                    </p>
                    <p class="fs-6 fs-md-4 fs-lg-3 reveal mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque velit totam incidunt, quibusdam voluptate dolorem iure, nobis odit porro nisi, nam, fuga unde ipsum quae labore explicabo aspernatur nulla eius!
                    </p>
                </div>
                <hr>
                <div class="row justify-content-center align-items-center g-5">
                    <div class="col-12 col-md-6">
                        <form method="post">
                            <div class="card bg-dark text-light reveal">
                                <div class="card-header">
                                    <h1 class="fw-bold my-3 reveal">Contact Form</h1>
                                </div>
                                <div class="card-body">
                                    <!-- Name input -->
                                    <div class="form-outline mb-4 reveal">
                                        <input type="text" id="form2Example1" class="form-control" />
                                        <label class="form-label text-light" for="form2Example1">Your Name</label>
                                    </div>

                                    <!-- E-Mail input -->
                                    <div class="form-outline mb-4 reveal">
                                        <input type="email" id="form2Example2" class="form-control" />
                                        <label class="form-label text-light" for="form2Example2">Your Email</label>
                                    </div>

                                    <!-- Message input -->
                                    <div class="form-outline mb-4 reveal">
                                        <textarea cols="" rows="3" class="form-control"></textarea>
                                        <label class="form-label text-light" for="form2Example2">Your Email</label>
                                    </div>

                                    <!-- Submit button -->
                                    <button type="button" class="btn btn-outline-light btn-block mb-4 reveal">Submit</button>

                                    <!-- Register buttons -->

                                    <div class="text-center reveal">
                                        <p>
                                            or contact us in:
                                        </p>
                                        <button type="button" class="btn btn-primary btn-floating mx-1">
                                            <i class="fab fa-facebook-f"></i>
                                        </button>

                                        <button type="button" class="btn btn-danger btn-floating mx-1">
                                            <i class="fab fa-google"></i>
                                        </button>

                                        <button type="button" class="btn btn-info btn-floating mx-1">
                                            <i class="fab fa-twitter"></i>
                                        </button>

                                        <button type="button" class="btn btn-light text-dark btn-floating mx-1">
                                            <i class="fab fa-github"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="items">
                            <div class="item my-4 reveal">
                                <i class="fas fa-location-arrow text-dark" style="width: 4rem; height: 4rem;"></i>
                                <p class="lead fw-bold">
                                    Taguig City, New Lower Bicutan, 1631, PH
                                </p>
                            </div>
                            <div class="item my-4 reveal">
                                <i class="fas fa-phone text-dark" style="width: 4rem; height: 4rem;"></i>
                                <p class="lead fw-bold">
                                    +639123456789
                                </p>
                            </div>
                            <div class="item my-4 reveal">
                                <i class="fas fa-envelope text-dark" style="width: 4rem; height: 4rem;"></i>
                                <p class="lead fw-bold">
                                    dmaxportfolio@gmail.com
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="pt-4">
            <div class="content rounded bg-dark text-light text-center p-5 reveal">
                <h3 class="brand fw-bold py-5 reveal">-=D'Max'05=-</h3>
                <p class="lead pb-5 reveal">
                    <span class="fw-bold">Jonard Solayao</span> &copy; All Copy Rights Reserved 2021
                </p>
            </div>
        </footer>

    </div>


    <script src="/mdbootstrap/js/all.min.js"></script>
    <script src="/mdbootstrap/js/jquery.min.js"></script>
    <script src="/mdbootstrap/js/mdb.min.js"></script>
    <script src="/mdbootstrap/js/scrollreveal.min.js"></script>
    <script src="/mdbootstrap/js/my-script.js"></script>

</body>
</html>