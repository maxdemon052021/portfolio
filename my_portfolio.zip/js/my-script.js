$(document).ready(function() {

    setTimeout(function() {
        $('#loading-screen').hide('slow');
    }, 2000);

    const sr = ScrollReveal({
        duration: 2000,
        delay: 400,
        reset: true
    });

    sr.reveal('.reveal');

    $('.nav-link').click(function() {
        $(this).closest('.navbar-nav').find('.active').removeClass('active');
        $(this).addClass('active');
    });

});